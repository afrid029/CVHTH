<?php 

$db = mysqli_connect('localhost', 'rmlrkp20_CVHTH_TEST_ADMIN', '=+;=nItQNm2+', 'rmlrkp20_CVHTH_test');

// if(!$db) {
//     header("Location: /err");
//     exit();
// }
?>