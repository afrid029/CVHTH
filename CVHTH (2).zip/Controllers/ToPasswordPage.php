<?php 
if(isset($_POST['submit'])){
    session_start();
    $_SESSION['email'] = $_POST['email'];

    // echo $_SESSION['email'];

    header("Location: /reset-password");
}else {
    // header("Location: /");
    echo 'Hii';
}
?>