<?php 


$db = mysqli_connect('localhost', 'root', '', 'cvhth');

// if(!$db) {
//     header("Location: /err");
//     exit();
// }
?>