<?php 

$db = mysqli_connect('localhost', 'root', '', 'CVHTH');

// if(!$db) {
//     header("Location: /err");
//     exit();
// }
?>